package com.example.movies.ui.networkservice

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitService {

    companion object{
        private const val BASE_URL_FEED="https://feed.profoundly.me/"
    }

    fun getRetrofit(baseurl: String)= Retrofit.Builder()
        .baseUrl(baseurl)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

}