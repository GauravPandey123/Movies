package com.example.movies.ui.respositoy

class MoviesRepository {
}