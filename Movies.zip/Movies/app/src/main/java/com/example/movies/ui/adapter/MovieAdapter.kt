package com.example.movies.ui.adapter

class MovieAdapter {




















}