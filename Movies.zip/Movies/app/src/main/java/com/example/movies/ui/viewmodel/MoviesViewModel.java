package com.example.movies.ui.viewmodel;

public class MoviesViewModel {
}
